gdjs.Scene4Code = {};

gdjs.Scene4Code.conditionTrue_0 = {val:false};
gdjs.Scene4Code.condition0IsTrue_0 = {val:false};


gdjs.Scene4Code.eventsList0xb0cf8 = function(runtimeScene) {

}; //End of gdjs.Scene4Code.eventsList0xb0cf8


gdjs.Scene4Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Scene4Code.eventsList0xb0cf8(runtimeScene);
return;
}
gdjs['Scene4Code'] = gdjs.Scene4Code;
