gdjs.Scene2Code = {};

gdjs.Scene2Code.conditionTrue_0 = {val:false};
gdjs.Scene2Code.condition0IsTrue_0 = {val:false};


gdjs.Scene2Code.eventsList0xb0cf8 = function(runtimeScene) {

}; //End of gdjs.Scene2Code.eventsList0xb0cf8


gdjs.Scene2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Scene2Code.eventsList0xb0cf8(runtimeScene);
return;
}
gdjs['Scene2Code'] = gdjs.Scene2Code;
