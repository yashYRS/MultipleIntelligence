gdjs.Scene3Code = {};

gdjs.Scene3Code.conditionTrue_0 = {val:false};
gdjs.Scene3Code.condition0IsTrue_0 = {val:false};


gdjs.Scene3Code.eventsList0xb0cf8 = function(runtimeScene) {

}; //End of gdjs.Scene3Code.eventsList0xb0cf8


gdjs.Scene3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Scene3Code.eventsList0xb0cf8(runtimeScene);
return;
}
gdjs['Scene3Code'] = gdjs.Scene3Code;
